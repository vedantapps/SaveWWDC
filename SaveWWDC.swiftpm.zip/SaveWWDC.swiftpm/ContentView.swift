//
//  ContentView.swift
//  SaveWWDC
//
//  Created by Vedant Malhotra on 4/10/22.
//

import SwiftUI
import UIKit

struct ContentView: View {
    var body: some View {
        NavigationView {
            // Load Starting View
            StartingView()
        }
        .navigationViewStyle(StackNavigationViewStyle())
        .navigationBarTitle("")
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
    }
}
