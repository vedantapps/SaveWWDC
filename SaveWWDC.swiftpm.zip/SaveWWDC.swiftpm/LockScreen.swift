//
//  LockScreen.swift
//  SaveWWDC
//
//  Created by Vedant Malhotra on 4/11/22.
//

import Foundation
import SwiftUI

struct LockScreen: View {
    // Vars for animations, and date/time to be shown on screen
    @State var bgAnimate = false
    let bg = [Color(red: 0.09, green: 0.18, blue: 0.26), Color(red: 0.00, green: 0.04, blue: 0.11), Color(red: 0.01, green: 0.01, blue: 0.03)]
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    @State var timeID = 0
    @State var currTime = ""
    @State var time = "9:41"
    let dateString = "Sunday, June 5"
    @State var showingMessage = false
    
    
    var body: some View {
        ZStack {
            // The background view
            LinearGradient(gradient: Gradient(colors: bg), startPoint: bgAnimate ? .topLeading : .bottomLeading, endPoint: bgAnimate ? .bottomTrailing : .topTrailing)
                .ignoresSafeArea(.all)
                .onAppear {
                    DispatchQueue.main.async {
                        withAnimation(.linear(duration: 3.0).repeatForever(autoreverses: true)) {
                            bgAnimate.toggle()
                        }
                        currTime = "\(Date().formatted(.dateTime.hour().minute()))"
                        
                        time = String(currTime.dropLast(2))
                        
                        
                    }
                }
                .onReceive(timer) {_ in
                    // Get only the hours and minutes of the current time
                    currTime = "\(Date().formatted(.dateTime.hour().minute()))"
                    time = String(currTime.dropLast(2))
                }
            VStack {
                
                Text("Intro")
                    .font(.system(size: 55, weight: .semibold, design: .rounded))
                    .foregroundColor(Color(red: 0.76, green: 0.88, blue: 0.90))
                
                Text("Tap on the message you get from Craig!")
                    .font(.system(size: 30, weight: .semibold, design: .rounded))
                    .foregroundColor(Color(red: 0.76, green: 0.88, blue: 0.90))
                    .padding(.bottom)
                
                // The lockscreen
                ScrollView(.vertical, showsIndicators: false) {
                    VStack {
                        Group {
                            Image(systemName: "lock.open.fill")
                                .font(.system(size: 40))
                                .offset(x: 8)
                                .frame(maxWidth: .infinity)
                                .padding(.top)
                            Text(time)
                                .font(.system(size: 65, weight: .light))
                                .id(timeID)
                            
                            Text(dateString)
                                .font(.system(size: 20))
                            
                            
                        }
                        .multilineTextAlignment(.center)
                        .foregroundColor(Color.white)
                        
                        // The WWDC Event calendar notification
                        WWDCEventView()
                            .background(.ultraThinMaterial)
                            .preferredColorScheme(.light)
                            .cornerRadius(15)
                            .padding(8)
                        
                        // Load the message from Craig after a delay, and link it to the next view
                        if showingMessage {
                            
                            NavigationLink {
                                MessagesApp()
                            } label: {
                                
                                MessageInitial()
                                    .background(.ultraThinMaterial)
                                    .preferredColorScheme(.light)
                                    .cornerRadius(15)
                                    .padding(8)
                                    .offset(y: -8)
                            }
                            .transition(.slide)
                        }
                        
                        Spacer()
                        
                        
                    }
                    .onAppear {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                            withAnimation(Animation.spring()) {
                            showingMessage.toggle()
                            }
                        }
                    }
                }
                .background(Image("MessageBG"))
                .frame(minWidth: 400, maxWidth: 430, minHeight: 600, maxHeight: 750)
                .cornerRadius(15)
                .padding(.bottom)
                
                
            }
            
        }
        .navigationBarTitle("")
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
        
    }
}

// MARK: WWDC Calendar View
struct WWDCEventView: View {
    
    
    var body: some View {
        
        ZStack {
            HStack {
                ZStack {
                    Color.white
                    VStack {
                        Text("MON")
                            .foregroundColor(Color(red: 0.92, green: 0.30, blue: 0.27))
                            .font(.system(size: 10, weight: .bold))
                        Text("6")
                            .foregroundColor(Color.black)
                            .font(.system(size: 20, weight: .light))
                    }
                }
                .frame(maxWidth: 40, maxHeight: 40)
                .cornerRadius(10)
                .padding(.leading, 10)
                
                VStack(alignment: .leading) {
                    Text("TIME SENSITIVE")
                        .foregroundColor(Color.black.opacity(0.5))
                        .font(.system(size: 12, weight: .medium))
                    
                    Text("WWDC22 Apple Keynote")
                        .foregroundColor(Color.black)
                        .font(.system(size: 14, weight: .medium))
                    
                    Text("Tomorrow at 10:00 AM")
                        .foregroundColor(Color.black)
                        .font(.system(size: 14, weight: .regular))
                    
                }
                .padding(.leading, 5)
                
                
                Spacer()
                
                VStack {
                    Text("Tomorrow, 10:00 AM")
                        .foregroundColor(Color.black.opacity(0.5))
                        .font(.system(size: 12, weight: .regular))
                        .padding()
                        .padding(.bottom)
                    Spacer()
                }
                
            }
        }
        .frame(maxHeight: 65)
    }
}

// MARK: Message Notification
struct MessageInitial: View {
    
    @State var messageName = ""
    
    var body: some View {
        
        ZStack {
            HStack {
                
                ZStack {
                    Color.purple.opacity(0.5)
                    Text("🍎")
                        .foregroundColor(Color(red: 0.92, green: 0.30, blue: 0.27))
                        .font(.system(size: 25, weight: .bold))
                    
                    
                    
                }
                .frame(maxWidth: 40, maxHeight: 40)
                .cornerRadius(25)
                .padding(.leading, 10)
                
                
                
                VStack(alignment: .leading) {
                    Text("Craig Federighi")
                        .foregroundColor(Color.black)
                        .font(.system(size: 14, weight: .medium))
                    
                    Text("Apple Event Group Chat")
                        .foregroundColor(Color.black)
                        .font(.system(size: 14, weight: .medium))
                    
                    Text("Hey \(messageName)! We need your help")
                        .foregroundColor(Color.black)
                        .font(.system(size: 14, weight: .regular))
                        .multilineTextAlignment(.leading)
                    
                }
                .padding(.leading, 5)
                
                Spacer()
                
                VStack {
                    Text("now")
                        .foregroundColor(Color.black.opacity(0.5))
                        .font(.system(size: 12, weight: .regular))
                        .padding()
                        .padding(.bottom)
                    Spacer()
                }
                
            }
            .overlay(
                HStack {
                ZStack {
                    Rectangle()
                        .frame(maxWidth: 16, maxHeight: 16)
                        .foregroundColor(Color(red: 0.38, green: 0.78, blue: 0.33))
                        .cornerRadius(5)
                    
                    Image(systemName: "message.fill")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(Color.white)
                        
                    
                }
                    Spacer()
                }
                    .padding(.leading, 35)
                    .padding(.top, 25)
                    .shadow(radius: 8)
            )
            
            
        }
        .frame(maxHeight: 75)
        .onAppear {
            if personName == "" {
                messageName = "WWDC attendee"
            } else {
                messageName = personName
            }
        }
        
        
    }
    
}

