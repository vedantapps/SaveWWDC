//
//  PencilDrawView.swift
//  SaveWWDC
//
//  Created by Vedant Malhotra on 4/23/22.
//

import Foundation
import UIKit
import SwiftUI
import PencilKit

// Save the picture drawn
var savedPic: UIImage = UIImage(systemName: "swift")!

struct PencilView: View {
    
    // The drawing view for the WWDC Drawing Challenge
    
    @Environment(\.dismiss) var dismiss
    @State var showResults = false
    @State var count = 0
    
    // Start a timer
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    
    let canvas = PKCanvasView()
    let picker = PKToolPicker()
    var body: some View {
        NavigationView {
            GeometryReader { geo in
                Canvas(canvas: canvas, picker: picker)
                    .toolbar {
                        ToolbarItem(placement: .navigationBarLeading) {
                            Text("Time elapsed: \(count)")
                        }
                        
                        ToolbarItemGroup(placement: .navigationBarTrailing) {
                            Button {
                                // let the user exit the drawing view early if they want
                                picker.setVisible(true, forFirstResponder: canvas)
                                canvas.becomeFirstResponder()
                            } label: {
                                Image(systemName: "paintpalette")
                            }
                            Button("Dismiss"){
                                timer.upstream.connect().cancel()
                                dismiss()
                                
                            }
                        }
                        
                    }
                    .foregroundColor(.blue)
                    .navigationTitle("WWDC Drawing Challenge")
                    .onReceive(timer){_ in
                        count += 1
                        if count >= 20 {
                            savedPic = canvas.drawing.image(from: CGRect(x: 0, y: 0, width: geo.size.width, height: geo.size.height), scale: 1.0)
                            timer.upstream.connect().cancel()
                            showResults = true
                        }
                    }
                    .background(NavigationLink(destination: ResultsView(), isActive: $showResults){})
            }
            
        }
        .preferredColorScheme(.dark)
    }
}

// MARK: Canvas
// Creating a bridge to connect to SwiftUI

struct Canvas: UIViewRepresentable {
    var canvas: PKCanvasView
    var picker = PKToolPicker.init()
    
    
    func makeUIView(context: Context) -> PKCanvasView {
        picker.colorUserInterfaceStyle = .dark
        canvas.tool = picker.selectedTool
        canvas.drawingPolicy = .pencilOnly
        picker.addObserver(canvas)
        
        return canvas
    }
    
    func updateUIView(_ uiView: PKCanvasView, context: Context) {
        picker.addObserver(canvas)
        picker.setVisible(true, forFirstResponder: uiView)
        
        canvas.tool = picker.selectedTool
        canvas.drawingPolicy = .pencilOnly
        
        
        DispatchQueue.main.async {
            self.canvas.becomeFirstResponder()
            uiView.becomeFirstResponder()
            
        }
    }
    
}

// MARK: Results
struct ResultsView: View {
    
    // Show the user an image of what they drew
    
    var body: some View {
        ScrollView {
            Image(uiImage: savedPic)
                .resizable()
                .scaledToFit()
                .frame(width: 500, height: 500)
                .border(Color(red: 0.76, green: 0.88, blue: 0.90), width: 10)
                .cornerRadius(15)
            
            VStack {
                Text("Not bad!")
                
                Text("Liked your drawing? Screenshot it and share it with the world!")
                    .padding()
            }
            .font(.system(size: 30, weight: .semibold, design: .rounded))
            .multilineTextAlignment(.center)
            
            Button {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "draw"), object: self, userInfo: nil)
            } label: {
                ZStack{
                    RoundedRectangle(cornerRadius: 15)
                        .foregroundColor(.blue)
                    
                    Text("I'm Finished")
                        .foregroundColor(.white)
                }
                .frame(width: 150, height: 45)
                .padding(.bottom)
            }
            
        }
        .preferredColorScheme(.dark)
        .navigationTitle("Results")
        .navigationBarBackButtonHidden(true)
    }
}
