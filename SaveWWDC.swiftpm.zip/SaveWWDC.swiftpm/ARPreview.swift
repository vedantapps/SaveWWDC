//
//  ARPreview.swift
//  SaveWWDC
//
//  Created by Vedant Malhotra on 4/23/22.
//

import Foundation
import SwiftUI
import QuickLook
import ARKit

// Creating a bridge to connect to SwiftUI
struct ARPreview: UIViewControllerRepresentable {
    typealias UIViewControllerType = viewiPad
    
    func makeCoordinator() -> Coordinator {
        return Coordinator(self)
    }
    
    func makeUIViewController(context: Context) -> viewiPad {
        let view = viewiPad()
        return view
    }
    
    func updateUIViewController(_ uiViewController: viewiPad, context: Context) {
    }
    
    class Coordinator: NSObject {
        var parent: ARPreview
        init(_ parent: ARPreview){
            self.parent = parent
        }
    }
}

// The main file to load
class viewiPad: UIViewController, QLPreviewControllerDataSource {
    let file = "WWDCPad"
    let fileType = "usdz"
    
    override func viewDidAppear(_ animated: Bool) {
        let previewController = QLPreviewController()
        previewController.dataSource = self
        present(previewController, animated: true, completion: nil)
    }
    
    func numberOfPreviewItems(in controller: QLPreviewController) -> Int {
        return 1
    }
    
    func previewController(_ controller: QLPreviewController, previewItemAt index: Int) -> QLPreviewItem {
        guard let fileURL = Bundle.main.path(forResource: file, ofType: fileType) else {
            fatalError("Error opening file.")
        }
        let url = URL(fileURLWithPath: fileURL)
        let preview = ARQuickLookPreviewItem(fileAt: url)
        preview.allowsContentScaling = true
        return preview
    }
    
}
