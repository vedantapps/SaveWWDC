//
//  MessagesApp.swift
//  SaveWWDC
//
//  Created by Vedant Malhotra on 4/18/22.
//

import Foundation
import SwiftUI

struct MessagesApp: View {
    @State var bgAnimate = false
    let bg = [Color(red: 0.09, green: 0.18, blue: 0.26), Color(red: 0.00, green: 0.04, blue: 0.11), Color(red: 0.01, green: 0.01, blue: 0.03)]
    @State var messageName = ""
    
    @State var isShowingMessage2 = false
    @State var isShowingMessage3 = false
    @State var isShowingMessage4 = false
    
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: bg), startPoint: bgAnimate ? .topLeading : .bottomLeading, endPoint: bgAnimate ? .bottomTrailing : .topTrailing)
                .ignoresSafeArea(.all)
            
            VStack {
                
                
                Text("The Story")
                    .font(.system(size: 55, weight: .semibold, design: .rounded))
                    .foregroundColor(Color(red: 0.76, green: 0.88, blue: 0.90))
                
                Text("Help the Apple team out!")
                    .font(.system(size: 30, weight: .semibold, design: .rounded))
                    .foregroundColor(Color(red: 0.76, green: 0.88, blue: 0.90))
                    .padding(.bottom)
                // Messages View Initial
                ZStack {
                    VStack {
                        
                        // The top bar in the messages app
                        ZStack{
                            Color.gray
                                .opacity(0.2)
                            
                            HStack {
                                Image(systemName: "chevron.backward")
                                    .font(.system(size: 25.0, weight: .medium))
                                    .foregroundColor(Color.blue)
                                    .padding(.leading, 30)
                                
                                Spacer()
                                
                                VStack {
                                    HStack {
                                        Spacer()
                                        HStack {
                                            ZStack {
                                                Circle()
                                                    .foregroundColor(Color(red: 0.60, green: 0.62, blue: 0.66))
                                                    .frame(maxWidth: 24, maxHeight: 24)
                                                Text("T")
                                                    .foregroundColor(Color.white)
                                                    .font(.system(size: 13, weight: .light))
                                            }
                                            .shadow(radius: 2)
                                            .offset(y: -13)
                                            
                                            ZStack {
                                                Color.purple.opacity(0.5)
                                                Text("🍎")
                                                    .foregroundColor(Color(red: 0.92, green: 0.30, blue: 0.27))
                                                    .font(.system(size: 35, weight: .bold))
                                            }
                                            .frame(maxWidth: 60, maxHeight: 60)
                                            .cornerRadius(35)
                                            
                                            
                                            ZStack {
                                                Circle()
                                                    .foregroundColor(Color(red: 0.60, green: 0.62, blue: 0.66))
                                                    .frame(maxWidth: 24, maxHeight: 24)
                                                Text("C")
                                                    .foregroundColor(Color.white)
                                                    .font(.system(size: 13, weight: .light))
                                            }
                                            .shadow(radius: 2)
                                            .offset(y: 13)
                                            
                                        }
                                        Spacer()
                                    }
                                    Text("Apple Event Group Chat")
                                        .foregroundColor(Color.black)
                                        .multilineTextAlignment(.center)
                                        .font(.system(size: 14, weight: .regular))
                                    
                                    
                                    
                                }
                                Image(systemName: "video")
                                    .font(.system(size: 24.0, weight: .regular))
                                    .foregroundColor(Color.blue)
                                    .padding(.trailing, 30)
                                
                            }
                            
                        }
                        .frame(maxWidth: .infinity, maxHeight: 115)
                        
                        
                        Spacer()
                        
                        // Show messages from Craig and Tim
                        // Using binding to reuse same view
                        ScrollView(.vertical, showsIndicators: false) {
                            HStack {
                                MessageItem(nameOfPerson: .constant("Craig Federighi"), icon: .constant("C"), message: .constant("Hey \(messageName)! We need your help"))
                                    .padding(.leading)
                                Spacer()
                            }
                            
                            
                            if isShowingMessage2 {
                                
                                HStack {
                                    MessageItem(nameOfPerson: .constant("Tim Cook"), icon: .constant("T"), message: .constant("The event is just minutes away and Craig is about to present!!"))
                                        .padding(.leading)
                                    Spacer()
                                }
                                .transition(.slide)
                            }
                            
                            
                            if isShowingMessage3 {
                                
                                HStack {
                                    MessageItem(nameOfPerson: .constant("Craig Federighi"), icon: .constant("C"), message: .constant("I forgot to update my iPad to iPadOS 16! \(messageName), could you please help me update my iPad using the DeviceRestore application, so I can demo the latest features to the audience?"))
                                        .padding(.leading)
                                    Spacer()
                                }
                                .transition(.slide)
                            }
                            
                            if isShowingMessage4 {
                                
                                HStack {
                                    MessageItem(nameOfPerson: .constant("Craig Federighi"), icon: .constant("C"), message: .constant("Are you up for the task?"))
                                        .padding(.leading)
                                    Spacer()
                                }
                                .transition(.slide)
                                
                                NavigationLink {
                                    MacView()
                                } label: {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 15)
                                            .foregroundColor(Color.blue.opacity(0.5))
                                            .frame(minHeight: 50)
                                        Text("Let's do it!")
                                            .font(.system(size: 30, weight: .semibold, design: .rounded))
                                            .foregroundColor(Color.black)
                                    }
                                    .padding()
                                }
                            }

                        }
                        
                        .background(Color.white)
                    }
                }
                .background(Color.white)
                .frame(minWidth: 400, maxWidth: 430, minHeight: 600, maxHeight: 750)
                .cornerRadius(15)
                .padding(.bottom)

            }

        }
        .navigationBarTitle("")
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
        .onAppear {
            // Checks if user inputted a name in the starting view, if not use WWDC attendee
            if personName == "" {
                messageName = "WWDC attendee"
            } else {
                messageName = personName
            }
            
            // Show messages after a bit of a delay
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                withAnimation {
                    isShowingMessage2.toggle()
                }
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                withAnimation {
                    isShowingMessage3.toggle()
                }
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 5.5) {
                withAnimation {
                    isShowingMessage4.toggle()
                }
            }
            
            
        }
        
    }
    
}

// MARK: Reusable message view
struct MessageItem: View {
    
    @Binding var nameOfPerson: String
    @Binding var icon: String
    @Binding var message: String
    
    var body: some View {
        VStack(alignment: .leading) {
            Text(nameOfPerson)
                .foregroundColor(Color(uiColor: UIColor.lightGray))
                .font(.system(size: 13, weight: .regular))
                .offset(x: 45, y: 8)
            HStack {
                ZStack {
                    Circle()
                        .foregroundColor(Color(red: 0.60, green: 0.62, blue: 0.66))
                        .frame(width: 35, height: 35)
                    Text(icon)
                        .foregroundColor(Color.white)
                        .font(.system(size: 18, weight: .light))
                }
                
                ZStack {
                    RoundedRectangle(cornerRadius: 10)
                        .foregroundColor(Color(red: 0.91, green: 0.91, blue: 0.92))
                    HStack {
                        Text(message)
                            .font(.system(size: 16, weight: .regular))
                            .foregroundColor(Color.black)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(5)
                    }
                }
                
            }
        }
        .frame(maxWidth: 290, maxHeight: 200)
    }
}
