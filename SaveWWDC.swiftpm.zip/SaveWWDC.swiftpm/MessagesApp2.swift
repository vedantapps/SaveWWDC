//
//  MessagesApp2.swift
//  SaveWWDC
//
//  Created by Vedant Malhotra on 4/23/22.
//

import Foundation
import SwiftUI

struct MessagesApp2: View {
    
    // This view continues the story after the device has been restored
    
    @State var bgAnimate = false
    let bg = [Color(red: 0.09, green: 0.18, blue: 0.26), Color(red: 0.00, green: 0.04, blue: 0.11), Color(red: 0.01, green: 0.01, blue: 0.03)]
    @State var messageName = ""
    
    @State var isShowingMessage1 = false
    @State var isShowingMessage2 = false
    @State var isShowingMessage3 = false
    @State var isShowingMessage4 = false
    
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: bg), startPoint: bgAnimate ? .topLeading : .bottomLeading, endPoint: bgAnimate ? .bottomTrailing : .topTrailing)
                .ignoresSafeArea(.all)
            
            VStack {

                Text("You saved the day!")
                    .font(.system(size: 55, weight: .semibold, design: .rounded))
                    .foregroundColor(Color(red: 0.76, green: 0.88, blue: 0.90))
                
                
                ZStack {
                    VStack {
                        
                        // The top bar
                        ZStack{
                            Color.gray
                                .opacity(0.2)
                            
                            HStack {
                                Image(systemName: "chevron.backward")
                                    .font(.system(size: 25.0, weight: .medium))
                                    .foregroundColor(Color.blue)
                                    .padding(.leading, 30)
                                
                                Spacer()
                                
                                VStack {
                                    HStack {
                                        Spacer()
                                        HStack {
                                            ZStack {
                                                Circle()
                                                    .foregroundColor(Color(red: 0.60, green: 0.62, blue: 0.66))
                                                    .frame(maxWidth: 24, maxHeight: 24)
                                                Text("T")
                                                    .foregroundColor(Color.white)
                                                    .font(.system(size: 13, weight: .light))
                                            }
                                            .shadow(radius: 2)
                                            .offset(y: -13)
                                            
                                            ZStack {
                                                Color.purple.opacity(0.5)
                                                Text("🍎")
                                                    .foregroundColor(Color(red: 0.92, green: 0.30, blue: 0.27))
                                                    .font(.system(size: 35, weight: .bold))
                                            }
                                            .frame(maxWidth: 60, maxHeight: 60)
                                            .cornerRadius(35)
                                            
                                            
                                            ZStack {
                                                Circle()
                                                    .foregroundColor(Color(red: 0.60, green: 0.62, blue: 0.66))
                                                    .frame(maxWidth: 24, maxHeight: 24)
                                                Text("C")
                                                    .foregroundColor(Color.white)
                                                    .font(.system(size: 13, weight: .light))
                                            }
                                            .shadow(radius: 2)
                                            .offset(y: 13)
                                            
                                        }
                                        Spacer()
                                    }
                                    Text("Apple Event Group Chat")
                                        .foregroundColor(Color.black)
                                        .multilineTextAlignment(.center)
                                        .font(.system(size: 14, weight: .regular))
                                    
                                    
                                    
                                }
                                Image(systemName: "video")
                                    .font(.system(size: 24.0, weight: .regular))
                                    .foregroundColor(Color.blue)
                                    .padding(.trailing, 30)
                                
                            }
                            
                        }
                        .frame(maxWidth: .infinity, maxHeight: 115)
                        
                        
                        Spacer()
                        // Messages
                        ScrollView(.vertical, showsIndicators: false) {
                            
                            VStack {
                               
                                
                                ZStack {
                                    RoundedRectangle(cornerRadius: 10)
                                        .foregroundColor(Color(red: 0.20, green: 0.47, blue: 0.96))
                                    
                                    HStack {
                                        // Message being sent from the user
                                        Spacer()
                                        Text("Hey Craig, I have updated your iPad to iPadOS 16! Hopefully just in time for the event 🙂")
                                            .font(.system(size: 16, weight: .regular))
                                            .foregroundColor(Color.white)
                                            .frame(maxWidth: .infinity, alignment: .leading)
                                            .padding(5)
                                    }
                                }
                                
                                
                                
                            }
                            .offset(x: 50)
                            
                            .frame(minWidth: 290, maxWidth: 290)
                            Color.white
                                .frame(minWidth: 400, maxWidth: 430, minHeight: 1, maxHeight: 1.1)

                            if isShowingMessage1 {
                            HStack {
                                MessageItem(nameOfPerson: .constant("Craig Federighi"), icon: .constant("C"), message: .constant("\(messageName)! You saved the event, and we have some time to spare!"))
                                    .padding(.leading)
                                Spacer()
                            }
                            .transition(.slide)
                            }
                            
                            if isShowingMessage2 {
                                
                                HStack {
                                    MessageItem(nameOfPerson: .constant("Tim Cook"), icon: .constant("T"), message: .constant("Time to show all the new things we have in store 🎉🥳"))
                                        .padding(.leading)
                                    Spacer()
                                }
                                .transition(.slide)
                            }
                            
                            
                            if isShowingMessage3 {
                                
                                HStack {
                                    MessageItem(nameOfPerson: .constant("Craig Federighi"), icon: .constant("C"), message: .constant("We still got some time, so feel free to go back and check out the other applications. There might even be a cool AR experience in the iPadOS 16 preview 😉"))
                                        .padding(.leading)
                                        
                                    Spacer()
                                }
                                .transition(.slide)
                            }
                            
                            if isShowingMessage4 {
                                
                                HStack {
                                    MessageItem(nameOfPerson: .constant("Craig Federighi"), icon: .constant("C"), message: .constant("Tap the button below to go back and have some fun!"))
                                        .padding(.leading)
                                        
                                    Spacer()
                                }
                                .transition(.slide)
                                
                                NavigationLink {
                                    // Prompt the user to go back and explore the other applications
                                    MacView()
                                } label: {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 15)
                                            .foregroundColor(Color.blue.opacity(0.5))
                                            .frame(minHeight: 50)
                                        Text("Back to Applications")
                                            .font(.system(size: 30, weight: .semibold, design: .rounded))
                                            .foregroundColor(Color.black)
                                    }
                                    .padding()
                                }
                            }
                            
                            
                        }
                        
                        .background(Color.white)
                    }
                }
                .background(Color.white)
                .frame(minWidth: 400, maxWidth: 430, minHeight: 600, maxHeight: 750)
                .cornerRadius(15)
                .padding(.bottom)

                
            }

        }
        .navigationBarTitle("")
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
        .onAppear {

            // Checks if user put their name in the starting view, if not, uses WWDC attendee
            if personName == "" {
                messageName = "Thanks, WWDC attendee"
            } else {
                messageName = "Thanks, \(personName)"
            }
            
            // Show messages with a bit of delay to them
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                withAnimation {
                    isShowingMessage1.toggle()
                }
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
                withAnimation {
                    isShowingMessage2.toggle()
                }
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 5.2) {
                withAnimation{
                    isShowingMessage3.toggle()
                }
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 8.0) {
                withAnimation {
                    isShowingMessage4.toggle()
                }
            }
            
        }
        
    }
    
}
