//
//  StartingView.swift
//  SaveWWDC
//
//  Created by Vedant Malhotra on 4/10/22.
//

import Foundation
import SwiftUI

var personName = ""

struct StartingView: View {
    
    // Circle Animation
    @State var max = false
    let starting: CGFloat = 0.7
    let animation = Animation.easeInOut(duration: 6).repeatForever(autoreverses: true)
    let colors = [Color(red: 0.22, green: 0.06, blue: 0.60), Color(red: 0.13, green: 0.08, blue: 0.89), Color(red: 0.00, green: 0.98, blue: 0.84), Color(red: 0.98, green: 0.99, blue: 0.51), Color(red: 0.78, green: 0.58, blue: 0.31), Color(red: 0.44, green: 0.02, blue: 0.44)]
    
    //Background Animation
    let bg = [Color(red: 0.09, green: 0.18, blue: 0.26), Color(red: 0.00, green: 0.04, blue: 0.11), Color(red: 0.01, green: 0.01, blue: 0.03)]
    @State var bgAnimate = false
    
    @State var name: String = ""
    @FocusState var isFocused: Bool
    @State var blurAmount = 0
    
    
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: bg), startPoint: bgAnimate ? .topLeading : .bottomLeading, endPoint: bgAnimate ? .bottomTrailing : .topTrailing)
                .ignoresSafeArea(.all)
                .onAppear {
                    DispatchQueue.main.async {
                        withAnimation(.linear(duration: 3.0).repeatForever(autoreverses: true)) {
                            bgAnimate.toggle()
                        }
                    }
                }
            
            VStack {
                ScrollView {
                    
                    Text("Save WWDC!")
                        .font(.system(size: 55, weight: .semibold, design: .rounded))
                        .padding(.bottom)
                    Text("The big day is right around the corner, but something went wrong. Help the Apple team out before Craig presents on stage!")
                        .frame(maxWidth: 400)
                        .multilineTextAlignment(.center)
                        .font(.system(size: 25, weight: .semibold, design: .rounded))
                    
                }
                .frame(maxHeight: 250)
                .blur(radius: isFocused ? 20 : 0)
                .foregroundColor(Color(red: 0.76, green: 0.88, blue: 0.90))
                
                
                ZStack {
                    Color.white.opacity(0.8)
                    HStack {
                        ZStack(alignment: .leading) {
                            if name.isEmpty {
                                Text("Enter your name (Optional)")
                                    .foregroundColor(Color.gray)
                                    .padding()
                            }
                            TextField("", text: $name)
                                .padding()
                                .focused($isFocused)
                                .onChange(of: name) {_ in
                                    DispatchQueue.main.async {
                                        personName = name
                                    }
                                }
                        }
                        Spacer()
                        
                        Button {
                            isFocused = false
                        } label: {
                            Text("Done")
                        }
                        .padding(.trailing)
                        
                    }
                }
                .foregroundColor(Color.black)
                .frame(maxWidth: 400, maxHeight: 50)
                .cornerRadius(15)
                .padding()
                
                
                NavigationLink {
                    LockScreen()
                } label: {
                    ZStack {
                        Circle()
                            .strokeBorder(LinearGradient(gradient: Gradient(colors: colors), startPoint: .leading, endPoint: .trailing), lineWidth: 20)
                            .foregroundColor(Color.black.opacity(0.0))
                            .frame(maxWidth: 300)
                            .opacity(0.4)
                            .scaleEffect(max ? starting : 0.9)
                            .onAppear {
                                DispatchQueue.main.async {
                                    withAnimation(self.animation, {
                                        max = true
                                    })
                                }
                            }
                        
                        Text("Start")
                            .font(.system(size: 50, weight: .heavy, design: .rounded))
                            .foregroundColor(Color.white)
                    }
                    .ignoresSafeArea(.keyboard)
                    .frame(maxHeight: 300)
                }
                
            }
            
        }
        .navigationBarTitle("")
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
    }
}
