//
//  MacView.swift
//  SaveWWDC
//
//  Created by Vedant Malhotra on 4/22/22.
//

import Foundation
import SwiftUI

var deviceRestoreCounter = 0


struct MacView: View {
    
    // Vars to manage the mini apps
    @State var isShowingWWDCView = false
    @State var isShowingDeviceRestore = false
    @State var isShowingNewVersion = false
    @State var restart = false
    
    // Vars to show detail views
    @State var showHelp = false
    @State var restartMessage = false
    @State var showingNextView = false
    @State var showingARView = false
    
    @State var showingRestoreAlert = false
    
    let closeWWDCView = NotificationCenter.default.publisher(for: NSNotification.Name("dubDub"))
    let closeDeviceRestore = NotificationCenter.default.publisher(for: NSNotification.Name("deviceRestore"))
    let closeDeviceRestore2 = NotificationCenter.default.publisher(for: NSNotification.Name("deviceRestore2"))
    
    let closeARView = NotificationCenter.default.publisher(for: NSNotification.Name("closeAR"))
    
    var body: some View {
        ZStack {
            
            Image("MacBG")
                .resizable()
                .ignoresSafeArea()
            VStack {
                Text("Choose an application")
                    .foregroundColor(Color.white.opacity(0.8))
                    .font(.system(size: 32, weight: .light))
                
                
                ZStack {
                    RoundedRectangle(cornerRadius: 15)
                        .foregroundColor(Color.white.opacity(0.2))
                        .frame(minWidth: 600, maxWidth: 800, minHeight: 200, maxHeight: 240)
                    
                    
                    
                    HStack {
                        // MARK: DeviceRestore App
                        Button {
                            withAnimation(Animation.spring()) {
                                isShowingDeviceRestore.toggle()
                            }
                        } label: {
                            VStack {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 25)
                                        .frame(maxWidth: 150, maxHeight: 150)
                                        .foregroundColor(Color.white)
                                    Image(systemName: "ipad.and.iphone")
                                        .font(.system(size: 80, weight: .light))
                                        .foregroundColor(Color.orange.opacity(0.8))
                                    
                                }
                                .shadow(radius: 15)
                                Text("DeviceRestore")
                                    .foregroundColor(Color.white.opacity(0.8))
                                    .font(.system(size: 25, weight: .regular))
                            }
                        }
                        .frame(width: 240)
                        
                        // MARK: AR Preview App
                        Button {
                            // Checks to see if the main task in DeviceRestore has been done first
                            if deviceRestoreCounter == 0 {
                                showingRestoreAlert.toggle()
                            } else {
                                withAnimation(Animation.spring()) {
                                    isShowingNewVersion.toggle()
                                }
                            }
                            
                        } label: {
                            VStack {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 25)
                                        .frame(maxWidth: 150, maxHeight: 150)
                                        .foregroundColor(Color(red: 0.66, green: 0.76, blue: 0.85))
                                    Image(systemName: "apps.ipad.landscape")
                                        .font(.system(size: 80, weight: .light))
                                        .foregroundColor(Color.white.opacity(0.8))
                                    
                                }
                                .shadow(radius: 15)
                                Text("iPadOS 16 Preview")
                                    .foregroundColor(Color.white.opacity(0.8))
                                    .font(.system(size: 25, weight: .regular))
                            }
                        }
                        .frame(width: 240)
                        .alert("Time is ticking!\n\nHelp Craig update the demo iPad with the DeviceRestore application before he presents at WWDC! Once you are done, feel free to come back and play around!", isPresented: $showingRestoreAlert){
                            Button("Got it!", role: .cancel){}
                        }
                        
                        
                        // MARK: WWDC App
                        Button {
                            // Checks to see if the main task in DeviceRestore has been done first
                            if deviceRestoreCounter == 0 {
                                showingRestoreAlert.toggle()
                            } else {
                                withAnimation(Animation.spring()) {
                                    isShowingWWDCView.toggle()
                                }
                            }
                        } label: {
                            VStack {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 25)
                                        .frame(maxWidth: 150, maxHeight: 150)
                                        .foregroundColor(Color(red: 0.09, green: 0.17, blue: 0.25))
                                    Image(systemName: "swift")
                                        .font(.system(size: 80, weight: .heavy))
                                        .foregroundColor(Color.white.opacity(0.8))
                                    
                                }
                                .shadow(radius: 15)
                                Text("WWDC 2022")
                                    .foregroundColor(Color.white.opacity(0.8))
                                    .font(.system(size: 25, weight: .regular))
                            }
                        }
                        .frame(width: 240)
                        
                        
                    }
                    
                    
                }
                .padding()
                // Checks to see if the main task in DeviceRestore has been done
                if deviceRestoreCounter == 0 {
                    Button {
                        showHelp = true
                    } label: {
                        Text("Need help? Tap here!")
                            .foregroundColor(Color.white.opacity(0.8))
                            .font(.system(size: 26, weight: .light))
                    }
                    .alert("Help Craig!\n\nTurns out Craig's iPad is running iPadOS 15 and he is about to present at WWDC! Help Craig out by using the DeviceRestore application to update his iPad to iPadOS 16 to save the event.", isPresented: $showHelp){
                        Button("Got it!", role: .cancel){}
                    }
                    
                } else {
                    // If the main task has been completed, the user can choose to restart
                    Button {
                        restartMessage = true
                    } label: {
                        Text("Restart Experience")
                            .foregroundColor(Color.white.opacity(0.8))
                            .font(.system(size: 26, weight: .light))
                            .background(NavigationLink(destination: StartingView(), isActive: $restart){})
                    }
                    .alert("Restart Experience?\n\nAre you sure you would like to restart SaveWWDC? All current progress will be lost.", isPresented: $restartMessage){
                        Button("Yes", role: .destructive){
                            deviceRestoreCounter = 0
                            showingNextView = false
                            isShowingNewVersion = false
                            isShowingWWDCView = false
                            isShowingDeviceRestore = false
                            personName = ""
                            restart.toggle()
                        }
                        
                        Button("Cancel", role: .cancel){}
                    }
                }
                
                
            }
            .background(NavigationLink(destination: StartingView(), isActive: $restart){})
            
            
            // Note - Using VStack here fixes animation on close
            // App Views
            VStack {
                if isShowingWWDCView {
                    WWDC22App()
                        .transition(.scale)
                        .padding()
                }
            }
            .transition(.scale)
            
            VStack {
                if isShowingDeviceRestore {
                    Finder()
                        .transition(.scale)
                        .padding()
                }
            }
            .transition(.scale)
            
            VStack {
                if isShowingNewVersion {
                    NewVersionPreview()
                        .transition(.scale)
                        .padding()
                }
            }
            .transition(.scale)
            
            
            
        }
        
        // Checks to see if the mini app(s) needs to be closed
        .onReceive(closeWWDCView) {_ in
            withAnimation() {
                isShowingWWDCView = false
                
            }
        }
        .onReceive(closeDeviceRestore) {_ in
            withAnimation() {
                isShowingDeviceRestore = false
                
            }
        }
        .onReceive(closeDeviceRestore2) {_ in
            withAnimation() {
                isShowingDeviceRestore = false
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                showingNextView = true
            }
            
        }
        .onReceive(closeARView) {_ in
            withAnimation() {
                isShowingNewVersion = false
                
            }
        }
        // Navigate back to the messages to wrap up the story
        .background(NavigationLink(destination: MessagesApp2(), isActive: $showingNextView){}
        )
        
        
        .navigationBarTitle("")
        .navigationBarBackButtonHidden(true)
        .navigationBarHidden(true)
    }
}


// MARK: DeviceRestore App

struct Finder: View {
    
    @State var installTimer = Timer.publish(every: 0.2, on: .main, in: .common).autoconnect()
    @State var verifyTimer = Timer.publish(every: 0.1, on: .main, in: .common).autoconnect()
    @State var isShowingInstaller = false
    @State var isShowingVerify = false
    @State var progressAmount = 0.0
    @State var verifyAmount = 0.0
    @State var isButtonDisabled = false
    @State var isCloseDisabled = false
    @State var isShowingDoneButton = false
    
    // Using vars to update message if needed
    @State var softwareVersion = "iPadOS 15.4"
    @State var softwareMessage = "iPadOS 16 (Developer Beta) is ready to be installed on Craig's iPad"
    @State var buttonText = "Update to iPadOS 16"
    
    var body: some View {
        
        HStack(spacing: 0) {
            // Sidebar view (left)
            HStack {
                ZStack {
                    Image("MacBG")
                        .resizable()
                        .scaledToFill()
                    Color.white.opacity(0.6)
                    
                    
                    
                    VStack {
                        HStack {
                            Button {
                                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "deviceRestore"), object: self, userInfo: nil)
                                
                                
                            } label: {
                                Image(systemName: "x.circle.fill")
                                    .font(.system(size: 30, weight: .semibold, design: .rounded))
                                    .foregroundColor(.red)
                                    .background(.clear)
                            }
                            .disabled(isCloseDisabled)
                            // Prevents the user from closing the view while the device is being restored
                            
                            .padding()
                            Spacer()
                        }
                        .frame(minWidth: 150, maxWidth: 200)
                        
                        
                        VStack {
                            
                            Text("Locations")
                                .font(.system(size: 14, weight: .semibold, design: .rounded))
                                .foregroundColor(.gray)
                            
                        }
                        .padding(.leading)
                        .padding(.trailing)
                        .frame(minWidth: 150, maxWidth: 210, alignment: .leading)
                        
                        VStack {
                            ZStack {
                                RoundedRectangle(cornerRadius: 8)
                                    .frame(maxHeight: 40)
                                    .foregroundColor(.black.opacity(0.1))
                                    .padding(.leading)
                                    .padding(.trailing)
                                HStack {
                                    Image(systemName: "ipad")
                                        .font(.system(size: 15, weight: .semibold, design: .rounded))
                                        .foregroundColor(.black.opacity(0.5))
                                    Text("Craig's iPad")
                                        .font(.system(size: 15, weight: .regular, design: .rounded))
                                        .foregroundColor(Color(red: 0.20, green: 0.20, blue: 0.20))
                                        .padding(.trailing, 30)
                                    
                                    Image(systemName: "eject.fill")
                                        .font(.system(size: 15, weight: .regular, design: .rounded))
                                        .foregroundColor(.black.opacity(0.4))
                                        .padding(.trailing)
                                    
                                }
                            }
                        }
                        .padding(.leading)
                        .padding(.trailing)
                        .frame(minWidth: 150, maxWidth: 250, alignment: .leading)
                        
                        
                        VStack {
                            HStack {
                                Image(systemName: "network")
                                    .font(.system(size: 15, weight: .semibold, design: .rounded))
                                    .foregroundColor(.black.opacity(0.5))
                                Text("Network")
                                    .font(.system(size: 15, weight: .regular, design: .rounded))
                                    .foregroundColor(Color(red: 0.20, green: 0.20, blue: 0.20))
                                
                                
                                Spacer()
                                
                            }
                            
                        }
                        .padding(.leading)
                        .padding(.trailing)
                        .frame(minWidth: 150, maxWidth: 210, alignment: .leading)
                        
                        
                        Spacer()
                        
                        
                        
                    }
                }
            }
            
            .frame(minWidth: 150, maxWidth: 200, minHeight: 550, maxHeight: 600)
            
            // The view on the right (main view)
            
            HStack {
                VStack(spacing: 0) {
                    // Top Bar
                    ZStack {
                        Rectangle()
                            .foregroundColor(Color(red: 0.98, green: 0.96, blue: 0.98))
                            .frame(maxWidth: .infinity, minHeight: 40, maxHeight: 65)
                        HStack {
                            
                            Group {
                                Image(systemName: "chevron.left")
                                Image(systemName: "chevron.right")
                            }
                            .padding(.leading, 20)
                            .font(.system(size: 20, weight: .semibold, design: .rounded))
                            .foregroundColor(Color(red: 0.71, green: 0.70, blue: 0.71))
                            .frame(width: 30)
                            
                            Text("Craig's iPad")
                                .font(.system(size: 20, weight: .semibold, design: .rounded))
                                .foregroundColor(Color(red: 0.20, green: 0.20, blue: 0.20).opacity(0.8))
                                .padding(.leading, 10)
                            
                            
                            
                            
                            Spacer()
                            
                            Button{
                                
                            }label: {
                                Image(systemName: "square.and.arrow.up")
                                    .font(.system(size: 22, weight: .semibold, design: .rounded))
                                    .foregroundColor(Color(red: 0.71, green: 0.70, blue: 0.71))
                            }
                            .frame(width: 45)
                            
                            Button{}label: {
                                Image(systemName: "tag")
                                    .font(.system(size: 22, weight: .semibold, design: .rounded))
                                    .foregroundColor(Color(red: 0.71, green: 0.70, blue: 0.71))
                            }
                            .frame(width: 45)
                            
                            Button{}label: {
                                Image(systemName: "ellipsis.circle")
                                    .font(.system(size: 22, weight: .semibold, design: .rounded))
                                    .foregroundColor(Color(red: 0.71, green: 0.70, blue: 0.71))
                            }
                            .frame(width: 45)
                            
                            Spacer()
                                .frame(width: 50)
                            
                            Button{}label: {
                                Image(systemName: "magnifyingglass")
                                    .font(.system(size: 22, weight: .semibold, design: .rounded))
                                    .foregroundColor(Color(red: 0.71, green: 0.70, blue: 0.71))
                            }
                            .padding(.trailing, 20)
                            
                        }
                    }
                    
                    // Main view
                    ZStack {
                        Color(red: 0.93, green: 0.93, blue: 0.93)
                        VStack {
                            
                            HStack {
                                Image(systemName: "ipad")
                                    .font(.system(size: 52, weight: .semibold, design: .rounded))
                                    .foregroundColor(.black)
                                
                                VStack(alignment: .leading) {
                                    Text("Craig's iPad")
                                        .font(.system(size: 25, weight: .semibold, design: .rounded))
                                        .foregroundColor(.black)
                                    
                                    HStack {
                                        Text("iPad Pro - 256 GB (85.34 GB Available) - 100%")
                                            .font(.system(size: 18, weight: .semibold, design: .rounded))
                                            .foregroundColor(.black.opacity(0.5))
                                        
                                        Image(systemName: "battery.100.bolt")
                                            .font(.system(size: 20, weight: .semibold, design: .rounded))
                                            .foregroundColor(.green)
                                    }  
                                }
                                
                                Spacer()
                                
                            }
                            .padding(.leading)
                            .padding(.top)
                            
                            Divider()
                            
                            VStack {
                                VStack(alignment: .leading) {
                                    
                                    HStack {
                                        Text("Sofware: ")
                                            .font(.system(size: 16, weight: .bold, design: .default))
                                            .foregroundColor(.black)
                                        
                                        Text(softwareVersion)
                                            .font(.system(size: 16, weight: .medium, design: .default))
                                            .foregroundColor(.black)
                                    }
                                    
                                    Text(softwareMessage)
                                        .font(.system(size: 16, weight: .medium, design: .default))
                                        .foregroundColor(.black)
                                        .padding(.top, 15)
                                        .padding(.leading, 80)
                                    
                                    
                                    
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 10)
                                            .frame(maxWidth: 200, maxHeight: 35)
                                            .foregroundColor(.white)
                                        
                                        Button {
                                            withAnimation {
                                                isShowingInstaller.toggle()
                                                progressAmount = 0.0
                                                isShowingVerify = false
                                            }
                                        } label: {
                                            Text(buttonText)
                                                .foregroundColor(.black)
                                        }
                                        .frame(width: 200)
                                        .disabled(isButtonDisabled)
                                    }
                                    .padding(.top, 8)
                                    .padding(.leading, 80)
                                    
                                }
   
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.leading, 35)
                            .padding(.top, 20)
                            
                            Divider()
                                .padding(.top, 20)
                            
                            if isShowingInstaller {
                                ProgressView("Installing iPadOS 16 on Craig's iPad...", value: progressAmount, total: 100)
                                    .onAppear {
                                        progressAmount = 0.0
                                    }
                                    .onReceive(installTimer) {_ in
                                        if progressAmount < 100 {
                                            progressAmount += 2
                                        } else {
                                            installTimer.upstream.connect().cancel()
                                            withAnimation {
                                                isShowingVerify.toggle()
                                            }
                                        }
                                    }
                                    .padding()
                            }
                            
                            if isShowingVerify {
                                ProgressView("Verifying Install...", value: verifyAmount, total: 100)
                                    .onAppear {
                                        verifyAmount = 0.0
                                    }
                                    .onReceive(verifyTimer) {_ in
                                        if verifyAmount < 100 {
                                            verifyAmount += 2
                                            
                                        } else {
                                            verifyTimer.upstream.connect().cancel()
                                            withAnimation {
                                                softwareVersion = "iPadOS 16"
                                                softwareMessage = "Craig's iPad is up to date. Your device will automatically check for updates again on 6/10/22."
                                                isShowingDoneButton.toggle()
                                            }
                                            isButtonDisabled = true
                                            buttonText = "Check for Update"
                                            
                                            deviceRestoreCounter += 1
                                        }
                                    }
                                    .padding()
                            }
                            
                            if isShowingDoneButton {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 10)
                                        .frame(maxWidth: 100, maxHeight: 35)
                                        .foregroundColor(.white)
                                    
                                    Button {
                                        // Go back to the messages view to wrap up the story
                                        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "deviceRestore2"), object: self, userInfo: nil)
                                        
                                    } label: {
                                        
                                        Text("Done")
                                            .foregroundColor(.black)
                                            .frame(width: 100)
                                    }
                                    
                                    
                                }
                                .padding(.top, 8)
                                
                            }
                            
                            Spacer()
                                .onAppear {
                                    // Checks if device has already been restored
                                    if deviceRestoreCounter >= 1 {
                                        softwareVersion = "iPadOS 16"
                                        softwareMessage = "Craig's iPad is up to date. Your device will automatically check for updates again on 6/10/22."
                                        isButtonDisabled = true
                                        buttonText = "Check for Update"
                                    }
                                }
                        }
                    }
                }
            }
            
            .frame(minWidth: 450, maxWidth: 700, maxHeight: .infinity)
            
        }
        .onAppear {
            if deviceRestoreCounter < 1 {
                isCloseDisabled = true
            }
        }
        
        .cornerRadius(25)
        
        .frame(minWidth: 600, maxWidth: 900, minHeight: 550, maxHeight: 600)
    }
}

// MARK: iPadOS 16 Preview (AR App)

struct NewVersionPreview: View {
    
    @State var loadARView = false
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 25)
                .frame(minWidth: 600, maxWidth: 900, minHeight: 600, maxHeight: 700)
                .foregroundColor(Color(red: 0.09, green: 0.17, blue: 0.25))
            
            VStack {
                HStack {
                    Button {
                        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "closeAR"), object: self, userInfo: nil)
                        
                    } label: {
                        Image(systemName: "x.circle.fill")
                            .font(.system(size: 70, weight: .semibold, design: .rounded))
                            .foregroundColor(Color(red: 0.76, green: 0.88, blue: 0.90))
                    }
                    .padding()
                    
                    Spacer()
                }
                
                Spacer()
                VStack {
                    Image(systemName: "camera.on.rectangle")
                        .font(.system(size: 180, weight: .heavy))
                        .foregroundColor(Color.white.opacity(0.8))
                    
                    Text("An interactive AR experience")
                        .font(.system(size: 55, weight: .semibold, design: .rounded))
                        .padding(.bottom)
                    
                    Text("You might just see a preview of iPadOS 16 😉")
                        .font(.system(size: 30, weight: .semibold, design: .rounded))
                        .padding(.bottom)
                    
                    Text("Tap on objects to bring them to life!")
                        .font(.system(size: 30, weight: .semibold, design: .rounded))
                        .padding(.bottom, 5)
                    
                    Button {
                        loadARView.toggle()
                        // Shows the AR View from the ARPreview.swift file
                        
                    } label: {
                        HStack {
                            Text("Load AR Experience")
                                .font(.system(size: 30, weight: .semibold, design: .rounded))
                            
                            Image(systemName: "arrow.forward.circle")
                                .font(.system(size: 30, weight: .semibold, design: .rounded))
                        }
                    }
                    .padding()
                    
                    Text("Note - The camera feed may not work properly if the project is compiled on iPad, this seems to be a bug with Playgrounds. If compiled through Xcode onto the iPad, it works as intended.")
                        .font(.system(size: 15, weight: .semibold, design: .rounded))
                        .multilineTextAlignment(.center)
                    
                        .padding(5)
                    
                    
                    if loadARView {
                        ARPreview()
                    }
                    
                    
                }
                .onAppear {
                    loadARView = false
                }
                .foregroundColor(Color(red: 0.76, green: 0.88, blue: 0.90))
                .offset(y: -70)
                
                Spacer()
            }
        }
        .frame(minWidth: 600, maxWidth: 900, minHeight: 600, maxHeight: 700)
    }
}

// MARK: WWDC 2022 App
struct WWDC22App: View {
    
    @State var dateDiff = 0
    @State var showingDrawAlert = false
    @State var showingDrawView = false
    
    let closeDraw = NotificationCenter.default.publisher(for: NSNotification.Name("draw"))
    
    var body: some View {
        
        ZStack {
            RoundedRectangle(cornerRadius: 25)
                .frame(minWidth: 600, maxWidth: 900, minHeight: 600, maxHeight: 700)
                .foregroundColor(Color(red: 0.09, green: 0.17, blue: 0.25))

            
            VStack {
                HStack {
                    Button {
                        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "dubDub"), object: self, userInfo: nil)
                        
                    } label: {
                        Image(systemName: "x.circle.fill")
                            .font(.system(size: 70, weight: .semibold, design: .rounded))
                            .foregroundColor(Color(red: 0.76, green: 0.88, blue: 0.90))
                    }
                    .padding()
                    
                    Spacer()
                }
                
                Spacer()
                VStack {
                    Image(systemName: "swift")
                        .font(.system(size: 180, weight: .heavy))
                        .foregroundColor(Color.white.opacity(0.8))
                    
                    Text("WWDC 2022")
                        .font(.system(size: 55, weight: .semibold, design: .rounded))
                        .padding(.bottom)
                    
                    Text("WWDC 2022 will be held from June 6th to June 10th!")
                        .font(.system(size: 30, weight: .semibold, design: .rounded))
                        .padding(.bottom)
                    
                    Text("Days until WWDC 2022:")
                        .font(.system(size: 30, weight: .semibold, design: .rounded))
                        .padding(.bottom, 5)
                    
                    Text("\(dateDiff+1)")
                        .font(.system(size: 70, weight: .semibold, design: .rounded))
                        .padding(.bottom)
                    
                    Button {
                        // Button for Drawing Challenge
                        showingDrawAlert.toggle()
                    } label: {
                        HStack {
                            Text("Try the WWDC Drawing Challenge")
                                .font(.system(size: 25, weight: .semibold, design: .rounded))
                            Image(systemName: "arrow.forward.circle")
                                .font(.system(size: 35, weight: .semibold, design: .rounded))
                            
                        }
                        
                    }
                    .alert("WWDC Drawing Challenge\n\nGet your Apple Pencil Ready! You'll have 20 seconds to try and draw the Swift logo. The view will close automatically. Ready to try it?", isPresented: $showingDrawAlert){
                        Button("Start", role: .none){
                            showingDrawView = true
                        }
                        Button("Cancel", role: .cancel){}
                    }
                    .sheet(isPresented: $showingDrawView){
                        PencilView()
                            .preferredColorScheme(.dark)
                    }
                    
                }
                .foregroundColor(Color(red: 0.76, green: 0.88, blue: 0.90))
                .offset(y:-30)
                Spacer()
                
            }
            .foregroundColor(Color(red: 0.76, green: 0.88, blue: 0.90))
            .onAppear {
                // Calculate days until WWDC 2022
                
                let dubDubDate = "2022-06-06"
                let formatter = DateFormatter()
                formatter.dateFormat = "yyyy-MM-dd"
                
                let dubDubFormatted = formatter.date(from: dubDubDate)
                
                let currDate = Date()
                let components = Set<Calendar.Component>([.day])
                
                let difference = Calendar.current.dateComponents(components, from: currDate, to: dubDubFormatted!)
                
                dateDiff = difference.day!
            }
            .onReceive(closeDraw) {_ in
                withAnimation() {
                    showingDrawView.toggle()
                }
            }
        }
        
        
        .frame(minWidth: 600, maxWidth: 900, minHeight: 600, maxHeight: 700)
    }
}
